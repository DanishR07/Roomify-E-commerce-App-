class Product {
  String id;
  String price;
  String title;
  String description;
  String? image;

  Product(this.id, this.price, this.title, this.description);
  static Product fromMap(Map<String,dynamic> map){
    Product p=Product(map['id'], map['price'], map['title'], map['description']);
    p.image=map['image'];
    return p;
  }
  Map<String,dynamic> toMap (){
    return{
      'id': id,
      'image': image,
      'price': price,
      'title': title,
      'description': description,
    };
  }
}



// List<Product> products = [
//   Product(
//     id: 1,
//     price: 65,
//     title: "Classic Leather Arm Chair",
//     image: "assets/images/Item_1.png",
//     description:
//     "A timeless leather armchair perfect for living rooms or reading corners. Crafted with premium materials for comfort and durability.",
//   ),
//   Product(
//     id: 2,
//     price: 220,
//     title: "Poppy Plastic Tub Chair",
//     image: "assets/images/Item_2.png",
//     description:
//     "Modern design with ergonomic curves, the Poppy Chair fits beautifully in any minimalist or contemporary home.",
//   ),
//   Product(
//     id: 3,
//     price: 115,
//     title: "Mid-century Modern Sofa",
//     image: "assets/images/Item_3.png",
//     description:
//     "A sleek and stylish mid-century modern sofa perfect for small apartments and living rooms.",
//   ),
//   Product(
//     id: 4,
//     price: 335,
//     title: "Premium Leather Armchair",
//     image: "assets/images/item_4.png",
//     description:
//     "A premium leather armchair perfect for executive offices and luxury living rooms.",
//   ),
//   Product(
//     id: 5,
//     price: 60,
//     title: "Compact Tub Chair",
//     image: "assets/images/item_5.png",
//     description:
//     "Space-saving design with modern aesthetics, perfect for small spaces.",
//   ),
//   Product(
//     id: 6,
//     price: 235,
//     title: "Designer Modern Sofa",
//     image: "assets/images/item_6.png",
//     description:
//     "Contemporary design meets comfort in this stylish modern sofa.",
//   ),
// ];
