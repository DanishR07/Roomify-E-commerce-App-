class CartItem {
  final String id;
  final String productId;
  final String title;
  final String image;
  final double price;
  final int quantity;

  CartItem({
    required this.id,
    required this.productId,
    required this.title,
    required this.image,
    required this.price,
    required this.quantity,
  });

  factory CartItem.fromMap(Map<String, dynamic> map, String documentId) {
    double parsedPrice;
    if (map['price'] is num) {
      parsedPrice = (map['price'] as num).toDouble();
    } else if (map['price'] is String) {
      parsedPrice = double.tryParse(map['price']) ?? 0.0;
    } else {
      parsedPrice = 0.0;
    }
    int parsedQuantity;
    if (map['quantity'] is int) {
      parsedQuantity = map['quantity'] as int;
    } else if (map['quantity'] is String) {
      parsedQuantity = int.tryParse(map['quantity']) ?? 1;
    } else {
      parsedQuantity = 1;
    }
    return CartItem(
      id: documentId,
      productId: map['productId'],
      title: map['title'],
      image: map['image'],
      price: parsedPrice,
      quantity: parsedQuantity,
    );
  }
  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'title': title,
      'image': image,
      'price': price,
      'quantity': quantity,
    };
  }
}
