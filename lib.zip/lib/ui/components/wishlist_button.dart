import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../../models/Product.dart';
import '../../../models/wishlist_item.dart';

class WishlistButton extends StatefulWidget {
  final Product product;

  const WishlistButton({Key? key, required this.product}) : super(key: key);

  @override
  _WishlistButtonState createState() => _WishlistButtonState();
}

class _WishlistButtonState extends State<WishlistButton> {
  bool isInWishlist = false;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _checkWishlistStatus();
  }

  Future<void> _checkWishlistStatus() async {
    try {
      final wishlistRef = FirebaseFirestore.instance.collection('wishlistItems');
      final snapshot = await wishlistRef
          .where('productId', isEqualTo: widget.product.id)
          .get();

      setState(() {
        isInWishlist = snapshot.docs.isNotEmpty;
      });
    } catch (e) {
      print("Error checking wishlist status: $e");
    }
  }

  Future<void> _toggleWishlist() async {
    setState(() {
      isLoading = true;
    });

    try {
      final wishlistRef = FirebaseFirestore.instance.collection('wishlistItems');

      if (isInWishlist) {
        // Remove from wishlist
        final snapshot = await wishlistRef
            .where('productId', isEqualTo: widget.product.id)
            .get();

        for (var doc in snapshot.docs) {
          await doc.reference.delete();
        }

        setState(() {
          isInWishlist = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("${widget.product.title} removed from wishlist"),
            backgroundColor: Colors.orange,
          ),
        );
      } else {
        // Add to wishlist
        final wishlistItem = WishlistItem(
          id: '',
          productId: widget.product.id,
          title: widget.product.title,
          image: widget.product.image ?? '',
          price: widget.product.price,
          description: widget.product.description,
          timestamp: DateTime.now(),
        );

        await wishlistRef.add(wishlistItem.toMap());

        setState(() {
          isInWishlist = true;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("${widget.product.title} added to wishlist"),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error updating wishlist: $e"),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: isLoading ? null : _toggleWishlist,
      icon: isLoading
          ? SizedBox(
        width: 20,
        height: 20,
        child: CircularProgressIndicator(strokeWidth: 2),
      )
          : Icon(
        isInWishlist ? Icons.favorite : Icons.favorite_border,
        color: isInWishlist ? Colors.red : Colors.grey,
        size: 28,
      ),
    );
  }
}
