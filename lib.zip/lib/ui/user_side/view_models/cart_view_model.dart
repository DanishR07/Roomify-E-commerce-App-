import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../../models/cart_item.dart';

class CartViewModel extends ChangeNotifier {
  final cartRef = FirebaseFirestore.instance.collection('cartItems');
  List<CartItem> _cartItems = [];
  bool _isLoading = true;
  Set<String> _updatingItems = {};

  List<CartItem> get cartItems => _cartItems;
  bool get isLoading => _isLoading;
  Set<String> get updatingItems => _updatingItems;

  CartViewModel() {
    _loadCartItems();
  }

  Future<void> _loadCartItems() async {
    try {
      _isLoading = true;
      notifyListeners();

      final snapshot = await cartRef.orderBy('timestamp', descending: true).get();
      _cartItems = snapshot.docs
          .map((doc) => CartItem.fromMap(doc.data() as Map<String, dynamic>, doc.id))
          .toList();
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      // In a real app, you'd likely want to surface this error to the UI
      // perhaps via a stream or a callback. For this example, we'll
      // assume the UI handles its own snackbar based on state changes.
      print("Error loading cart: $e");
    }
  }

  Future<void> clearCart() async {
    try {
      final snapshot = await cartRef.get();
      for (var doc in snapshot.docs) {
        await doc.reference.delete();
      }
      await _loadCartItems(); // Reload after clearing
      // Notify UI for success
    } catch (e) {
      // Notify UI for error
      print("Error clearing cart: $e");
    }
  }

  Future<void> updateQuantity(CartItem item, int newQuantity) async {
    if (_updatingItems.contains(item.id)) return;

    try {
      _updatingItems.add(item.id);
      notifyListeners();

      if (newQuantity <= 0) {
        await deleteItem(item.id); // Use the view model's delete method
        return;
      }

      await cartRef.doc(item.id).update({'quantity': newQuantity});
      final index = _cartItems.indexWhere((cartItem) => cartItem.id == item.id);
      if (index != -1) {
        _cartItems[index] = CartItem(
          id: item.id,
          productId: item.productId,
          title: item.title,
          image: item.image,
          price: item.price,
          quantity: newQuantity,
        );
      }
      notifyListeners();
    } catch (e) {
      print("Error updating quantity: $e");
      // Notify UI for error
    } finally {
      _updatingItems.remove(item.id);
      notifyListeners();
    }
  }

  Future<void> deleteItem(String id) async {
    try {
      await cartRef.doc(id).delete();
      await _loadCartItems(); // Reload after deletion
      // Notify UI for success
    } catch (e) {
      // Notify UI for error
      print("Error removing item: $e");
    }
  }

  double calculateTotal() {
    return _cartItems.fold(0, (sum, item) => sum + (item.price * item.quantity));
  }
}